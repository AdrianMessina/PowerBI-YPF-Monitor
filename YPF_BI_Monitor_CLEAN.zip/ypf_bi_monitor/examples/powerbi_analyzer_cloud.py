"""
Example: Power BI Analyzer adapted for Cloudera AI Workbench
Demonstrates how to integrate the cloud-ready PBIP loader

BEFORE (Local environment):
    pbip_path = st.text_input("Ruta al archivo .pbip")
    if pbip_path and Path(pbip_path).exists():
        results = analyze_powerbi_file(pbip_path)

AFTER (Cloud-ready):
    pbip_path = load_pbip_cloud_ready(key="analyzer_upload")
    if pbip_path:
        results = analyze_powerbi_file(pbip_path)

That's it! The rest of the code remains the same.
"""

import streamlit as st
from pathlib import Path

# Import the cloud-ready loader
from shared.pbip_loader import load_pbip_cloud_ready, is_cloudera_environment

# Import your existing analyzer
from apps_core.analyzer_core.core import analyze_powerbi_file


def render_app_cloud_ready(logger):
    """
    Power BI Analyzer - Cloud Ready Version
    Works in both local and Cloudera environments
    """

    st.title("📊 Power BI Analyzer")
    st.markdown("Análisis completo de proyectos Power BI")

    # Show environment info (optional, for debugging)
    if is_cloudera_environment():
        st.info("☁️ Ejecutando en Cloudera AI Workbench")

    st.markdown("---")

    # ============================================================
    # 🎯 KEY CHANGE: Replace text_input with cloud-ready loader
    # ============================================================

    # OLD CODE (local only):
    # pbip_path = st.text_input(
    #     "📁 Ruta al archivo .pbip",
    #     placeholder="C:/Users/usuario/Documents/MiReporte/MiReporte.pbip"
    # )

    # NEW CODE (cloud-ready):
    pbip_path = load_pbip_cloud_ready(
        key="analyzer_upload",
        persistent_storage=True  # Enable project library
    )

    # ============================================================
    # Everything below this point remains UNCHANGED!
    # ============================================================

    if not pbip_path:
        # Show instructions while waiting for upload
        st.markdown("""
        ### 🚀 Primeros Pasos

        1. Prepara tu proyecto PBIP
        2. Comprime la carpeta completa en un ZIP
        3. Súbelo usando el selector arriba
        4. ¡El análisis comenzará automáticamente!
        """)
        return

    # Analyze button
    if st.button("🔍 Analizar Proyecto", type="primary", use_container_width=True):

        with st.spinner("Analizando proyecto Power BI..."):
            try:
                # Call your existing analyzer - no changes needed!
                results = analyze_powerbi_file(pbip_path)

                # Log usage (if logger available)
                if logger:
                    logger.log_action(
                        app_name="Power BI Analyzer",
                        action="analyze_pbip",
                        details={"project": Path(pbip_path).stem}
                    )

                # Store results in session state
                st.session_state.analysis_results = results
                st.success("✅ Análisis completado!")

            except Exception as e:
                st.error(f"❌ Error durante el análisis: {str(e)}")
                with st.expander("🔍 Ver detalles del error"):
                    import traceback
                    st.code(traceback.format_exc())
                return

    # Display results if available
    if 'analysis_results' in st.session_state:
        results = st.session_state.analysis_results

        st.markdown("---")
        st.markdown("## 📈 Resultados del Análisis")

        # Metrics overview
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric(
                "Tablas",
                results.get('total_tables', 0),
                help="Número total de tablas en el modelo"
            )

        with col2:
            st.metric(
                "Medidas DAX",
                results.get('total_measures', 0),
                help="Cantidad de medidas DAX creadas"
            )

        with col3:
            st.metric(
                "Relaciones",
                results.get('total_relationships', 0),
                help="Relaciones entre tablas"
            )

        with col4:
            score = results.get('health_score', 0)
            st.metric(
                "Score de Salud",
                f"{score}%",
                help="Puntuación general del modelo"
            )

        # Tabs for detailed results
        tabs = st.tabs([
            "📊 Métricas",
            "🗂️ Modelo de Datos",
            "📈 Visualizaciones",
            "📝 Medidas DAX"
        ])

        with tabs[0]:
            st.markdown("### Métricas Generales")
            # Your existing metrics rendering code here
            st.json(results.get('metrics', {}))

        with tabs[1]:
            st.markdown("### Modelo de Datos")
            # Your existing data model rendering code here
            st.json(results.get('data_model', {}))

        with tabs[2]:
            st.markdown("### Visualizaciones")
            # Your existing visualizations rendering code here
            st.json(results.get('visuals', {}))

        with tabs[3]:
            st.markdown("### Medidas DAX")
            # Your existing DAX measures rendering code here
            st.json(results.get('measures', {}))


# ============================================================
# COMPARISON: What changed?
# ============================================================

def render_app_OLD_LOCAL_ONLY(logger):
    """OLD VERSION - Only works with local file paths"""

    st.title("📊 Power BI Analyzer")

    # ❌ Only works locally - user must type full path
    pbip_path = st.text_input(
        "📁 Ruta al archivo .pbip",
        placeholder="C:/Users/usuario/Documents/MiReporte/MiReporte.pbip"
    )

    # Validate path exists
    if pbip_path and not Path(pbip_path).exists():
        st.error("❌ Archivo no encontrado")
        return

    if pbip_path:
        results = analyze_powerbi_file(pbip_path)
        # ... rest of the code


def render_app_NEW_CLOUD_READY(logger):
    """NEW VERSION - Works in both local and cloud"""

    st.title("📊 Power BI Analyzer")

    # ✅ Works anywhere - upload ZIP or select existing
    pbip_path = load_pbip_cloud_ready(
        key="analyzer_upload",
        persistent_storage=True
    )

    if pbip_path:
        results = analyze_powerbi_file(pbip_path)
        # ... rest of the code (UNCHANGED!)


# ============================================================
# Migration Checklist for Each App
# ============================================================

"""
TO MIGRATE AN APP TO CLOUD:

1. Add import:
   from shared.pbip_loader import load_pbip_cloud_ready

2. Replace this:
   pbip_path = st.text_input("Ruta al archivo .pbip")

   With this:
   pbip_path = load_pbip_cloud_ready(key="unique_key_here")

3. Remove path validation (the loader handles it):
   # DELETE THIS:
   if pbip_path and not Path(pbip_path).exists():
       st.error("File not found")

4. That's it! The rest of your code stays the same.

APPS TO UPDATE:
✅ apps/powerbi_analyzer.py
✅ apps/documentation_generator.py
✅ apps/dax_optimizer.py
✅ apps/layout_organizer.py
✅ apps/bi_bot.py (if it loads PBIP)

ESTIMATED TIME: 10-15 minutes per app
"""
